## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width=6
)

## ----message=FALSE, warning=FALSE, include=FALSE, paged.print=FALSE-----------
library(RELSA)
library(knitr)

## ----include=FALSE------------------------------------------------------------

############ BSL & General ##################
# load some data and subsets
raw          <- surgery

### Preprocessing (normalization)
vars         <- c("bwc", "burON","hr","hrv", "temp", "act")
turnvars     <- c("hr","temp" )

org          <- cbind(raw[,1:4], raw[,vars])
pre          <- relsa_norm(org,   normthese=c("burON","hr","hrv", "temp", "act"), ontime=1)

### Baseline (unscaled BUT PREPROCESSED data): THE BSL Values are NORMALIZED!
bsl          <- relsa_baselines(dataset=pre, bslday=-1, variables=vars, turnvars=turnvars)

### Determine k clusters and levels for the reference set
levels       <- relsa_levels(pre, mypath=NULL, bsl,
                             filename=NULL, drops=NULL, turns=c("hr","temp"), relsaNA=NA, k=4,
                             showScree="no", customCol= c("red","green","blue","magenta"), seed=123, myYlim=c(0,1.4), 
                             saveTiff="no")

##### Single Tests #########################################
testraw      <- surgery
vars         <- names(testraw[,-c(1:4)])
pre_test     <- cbind(testraw[,1:4], testraw[,vars])
testset      <- relsa_norm(pre_test, normthese=c("burON","hr","hrv", "temp", "act"), ontime=1)

unique(testset$id)


animal       <- 1
RELSA        <- relsa(set=testset, bsl, a=animal, drop=NULL, turnvars=c("hr","temp" ), relsaNA=NA)
relsascore   <- as.numeric(unlist(RELSA$relsa$rms))

 
RELSA2       <- relsa(set=testset, bsl, a=16, drop=NULL, turnvars=c("hr","temp" ), relsaNA=NA)
relsascore2  <- as.numeric(unlist(RELSA2$relsa$rms))
 

## ----include=FALSE------------------------------------------------------------
set      <- testset
a        <- 1
drop     <- NULL
turnvars <- c("hr", "temp" )
relsaNA  <- NA

### Build a data subset defined by the chosen animal
welchetiere  <- unique(set$id )
tage         <- length(set[set$id == welchetiere[a], 4])
Fr           <- NULL
subdata      <- round(set[set$id == welchetiere[a], 4:dim(set)[2]],2)
days         <- subdata$day


## ----echo=FALSE---------------------------------------------------------------
kable(head(subdata))

## ----include=FALSE------------------------------------------------------------
 ### Drop variables (check if the dropped vars are in the set, if so: do it)
  if( length(turnvars[turnvars %in% names(subdata)])==0 ){
    turnvars <- NULL
  }else{}

## ----echo=FALSE---------------------------------------------------------------
  if( is.null(drop)==TRUE ){
  }else{
    subdata[names(subdata) %in% drop] <- NULL
    turnvars                          <- turnvars[!(turnvars %in% drop)] # kick out dropped variables (for permutation!)
  }

  ### calculate difference matrix for the animal & turn vor positive variables
  if( is.null(turnvars)==TRUE ){
    delta            <- 100 - subdata[-1]
    bsdelta          <- 100 - bsl$maxsev
  }else{
    delta            <- 100 - subdata[-1]
    delta[,turnvars] <- delta[, turnvars]* -1

    bsdelta          <- 100 - bsl$maxsev         # for the extreme values of baseline vars
    bsdelta[turnvars]<- bsdelta[turnvars]* -1
  }



  ### set all negative values to NA - otherwise zero would allow usage in the mean!
  delta[delta<0]     <- 0
  delta              <- round(delta,2)
  kable(head(delta))
  
  # get the order of names in delta for baseline relsa score 2
  namen              <- names(delta)
  

## ----echo=FALSE---------------------------------------------------------------
 delta$days <-NULL
 wfactor    <- NULL
    for(r in 1:dim(delta)[1]){
      wfactor          <- as.data.frame(round( rbind(wfactor, delta[r,] / bsdelta[namen]), 2))
    }
 kable(head(wfactor))
  

## ----echo=FALSE---------------------------------------------------------------
wf_sum             <- round(apply(wfactor, 1, sum, na.rm=T),2 ) # Summarize
wf                 <- wf_sum  / (dim(wfactor)[2] - apply(apply(wfactor,2, is.na),1,sum))
   
if(length(wf)>0){
  wf[is.nan(wf)] <- relsaNA
}else{}

# if weights are smaller 0, kill them!
wf[wf <0]        <- relsaNA
    
# get NA positions for rms correction
na.idx           <- is.na(wf)

####### RELSA: score 2: METHOD 2 (RMS)
# RMS RELSA
rms     <- c()
    
for(l in 1:dim(delta)[1]){
  RMS                <- sqrt( sum( wfactor[l, ]^2 ,na.rm=TRUE )/ (length(wfactor[l, ]) - sum(is.na(wfactor[l, ])))  )
  if( sum(is.na(wfactor[l, ]))==length(names(wfactor)) ){ RMS<-NA} else {}
  rms[l]             <- RMS
  }
rms[na.idx]          <- NA
rms                  <- as.data.frame(rms)
    
final                <- data.frame(day=days, RELSA=round(rms,2))
colnames(final)      <- c("day", "RELSA")
kable(head(final))

## ----echo=FALSE, fig.height=5, fig.width=7------------------------------------
plot( c(-1:28), relsascore,  type="b", pch=19, col="red", xlim=c(-1,28), ylim=c(0,1.4), xlab="day", ylab="RELSA score" )
lines(c(-1:28), relsascore2, type="b", pch=19 )

abline(h=levels$level1, lwd=1, lty=2)
abline(h=levels$level2, lwd=1, lty=2)
abline(h=levels$level3, lwd=1, lty=2)
abline(h=levels$level4, lwd=1, lty=2)
#text(25,levels$level1+0.08, levels$level1 )
#text(25,levels$level2+0.08, levels$level2 )
#text(25,levels$level3+0.08, levels$level3 )
#text(25,levels$level4+0.08, levels$level4 )

legend("topright", c("TM","Sham"), pch=c(19,19), lty=c(1,1), col=c("red","black"), bty="n")


